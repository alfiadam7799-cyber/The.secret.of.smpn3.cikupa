const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const Upload = require('../models/Upload');

// Multer storage to 'uploads' folder
const storage = multer.diskStorage({
  destination: function(req, file, cb){
    cb(null, path.join(__dirname, '..', 'uploads'));
  },
  filename: function(req, file, cb){
    const unique = Date.now() + '-' + Math.round(Math.random()*1E9);
    cb(null, unique + path.extname(file.originalname));
  }
});
const upload = multer({ storage });

// Home - grid like YouTube thumbnails
router.get('/', async (req, res)=>{
  const uploads = await Upload.find().sort({ createdAt: -1 }).limit(50);
  res.render('index', { uploads });
});

// Upload form
router.get('/upload', (req, res)=>{
  res.render('upload');
});

// Handle upload - requires upload password
router.post('/upload', upload.single('photo'), async (req, res)=>{
  const { name, class: kelas, hobby, uploadPassword } = req.body;
  if(uploadPassword !== 'hutao cantik'){
    req.flash('error', 'Password upload salah.');
    if(req.file){
      // delete file
      const fs = require('fs');
      fs.unlinkSync(req.file.path);
    }
    return res.redirect('/upload');
  }
  const file = req.file;
  const u = new Upload({
    filename: file.filename,
    originalname: file.originalname,
    title: req.body.title || file.originalname,
    name,
    class: kelas,
    hobby
  });
  await u.save();
  req.flash('success', 'Upload berhasil!');
  res.redirect('/');
});

// Secret page (rahasi) - shows all uploads; kept separate route
router.get('/secret', async (req, res)=>{
  const uploads = await Upload.find().sort({ createdAt: -1 });
  res.render('secret', { uploads });
});

module.exports = router;
