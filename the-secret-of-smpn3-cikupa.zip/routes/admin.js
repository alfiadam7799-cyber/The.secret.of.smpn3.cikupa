const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Upload = require('../models/Upload');

// Admin login page
router.get('/login', (req, res)=>{
  res.render('admin_login');
});

// Handle login
router.post('/login', async (req, res)=>{
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if(!user) {
    req.flash('error', 'User tidak ditemukan.');
    return res.redirect('/admin/login');
  }
  const ok = await user.comparePassword(password);
  if(!ok){
    req.flash('error', 'Password salah.');
    return res.redirect('/admin/login');
  }
  req.session.user = { id: user._id, email: user.email, role: user.role };
  req.flash('success', 'Login berhasil.');
  res.redirect('/admin');
});

// Admin dashboard (list uploads)
router.get('/', async (req, res)=>{
  if(!req.session.user) {
    req.flash('error', 'Silakan login terlebih dahulu.');
    return res.redirect('/admin/login');
  }
  const uploads = await Upload.find().sort({ createdAt: -1 });
  res.render('admin_dashboard', { uploads });
});

// Logout
router.post('/logout', (req, res)=>{
  req.session.destroy();
  res.redirect('/');
});

module.exports = router;
