const mongoose = require('mongoose');

const uploadSchema = new mongoose.Schema({
  filename: String,
  originalname: String,
  title: String,
  name: String,
  class: String,
  hobby: String,
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Upload', uploadSchema);
